# 2506-sample-react

## 프로젝트 설치

```bash
npm install
npm run prepare
```

## 프로젝트 시작

```bash
npm run dev -- --turbo
```

## 스토리북 시작

```bash
npm run storybook
```
