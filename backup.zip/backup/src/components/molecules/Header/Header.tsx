// import { Base } from '@/styles/Base/Base.style';
// import { Style } from './Header.style';

interface Props {}

const Header = ({}: Props) => {
	return <>헤더</>;
};

export default Header;
