'use client';

import styled from 'styled-components';

export const Style = {
	Wrap: styled.div``
};