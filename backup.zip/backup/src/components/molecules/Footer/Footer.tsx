// import { Base } from '@/styles/Base/Base.style';
// import { Style } from './Footer.style';

interface Props {}

const Footer = ({}: Props) => {
	return <>푸터</>;
};

export default Footer;
