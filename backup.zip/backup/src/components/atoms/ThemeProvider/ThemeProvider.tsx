'use client';

import { darkTheme, lightTheme } from '@/constants/theme';
import useThemeStore from '@/stores/themeStore';
import GlobalStyle from '@/styles/Global.style';
import type { TChildren } from '@/types';
import { useEffect } from 'react';
import { ThemeProvider as Provider } from 'styled-components';

interface Props {
	children: TChildren;
}

const ThemeProvider = ({ children }: Props) => {
	const { themeMode, isLoaded, initializeTheme } = useThemeStore();

	useEffect(() => {
		initializeTheme();
	}, [initializeTheme]);

	if (!isLoaded) return null;

	const currentTheme = themeMode === 'light' ? lightTheme : darkTheme;

	return (
		<Provider theme={currentTheme}>
			<GlobalStyle />
			{children}
		</Provider>
	);
};

export default ThemeProvider;
