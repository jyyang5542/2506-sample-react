'use client';

import { CSSProperties } from 'react';

export const Style: CSSProperties = {
	fontFamily: 'monospace',
	fontSize: '0.9em'
};
