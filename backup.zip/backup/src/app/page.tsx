import { default as Main } from './Main/page';

export default Main;
