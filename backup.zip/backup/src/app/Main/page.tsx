import Main from '@/features/Main/Main';

interface Props {}

const Page = ({}: Props) => {
	return <Main />;
};

export default Page;
