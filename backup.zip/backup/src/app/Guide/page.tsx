import Guide from '@/features/Guide/Guide';

interface Props {}

const Page = ({}: Props) => {
	return <Guide />;
};

export default Page;
