import { COLORS } from '@/constants/colors';
import { hexToRgba } from '@/utils';
import { createGlobalStyle } from 'styled-components';

const GlobalStyle = createGlobalStyle`
  :root {
    --background: ${({ theme }) => theme.background};
    --text: ${({ theme }) => theme.text};
  }

  html,
  body {
    max-width: 100vw;
    overflow-x: hidden;
  }

  body {
    color: var(--text);
    background: var(--background);
    font-family: Arial, Helvetica, sans-serif;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;

    &::-webkit-scrollbar {
      width: 10px;
      height: 10px;
      background: ${COLORS.transparent};
    }

    &::-webkit-scrollbar-thumb {
      background-color: ${({ theme }) => hexToRgba(theme.text, 0.3)};
      border-radius: 5px;
    }

    &::-webkit-scrollbar-track {
      background: ${COLORS.transparent};
    }

    &::-webkit-scrollbar-button,
    &::-webkit-scrollbar-corner {
      display: none;
      height: 0;
      width: 0;
    }

    * {
      scrollbar-width: thin;
      scrollbar-color: ${({ theme }) => `${hexToRgba(theme.text, 0.3)} ${COLORS.transparent}`};
    }
  }

  * {
    box-sizing: border-box;
    padding: 0;
    margin: 0;
  }

  a {
    color: inherit;
    text-decoration: none;
  }

  @media (prefers-color-scheme: dark) {
    html {
      color-scheme: dark;
    }
  }
`;

export default GlobalStyle;
