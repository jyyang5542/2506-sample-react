const withSourceCode = (code: string) => ({
	docs: { source: { code } }
});

export default withSourceCode;
