import { COLORS } from '@/constants/colors';
import type { DefaultTheme } from 'styled-components';

export const lightTheme: DefaultTheme = {
	background: COLORS.white,
	text: COLORS.gray2
};

export const darkTheme: DefaultTheme = {
	background: COLORS.gray2,
	text: COLORS.white
};
