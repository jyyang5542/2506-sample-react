export enum Section {
	DEFAULT = '/',
	MAIN = '/Main',
	CATEGORY = '/Category'
}
