export enum Project {
	NAME = '프로젝트명',
	DESCRIPTION = '프로젝트 설명'
}
