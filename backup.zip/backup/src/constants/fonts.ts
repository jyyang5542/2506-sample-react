export const FONTS = {
	FAMILY: {},
	WEIGHT: {
		LIGHT: 300,
		MEDIUM: 400,
		BOLD: 600
	}
} as const;
